﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SDTEWebApplication;
using SDTEWebApplication.Controllers;
using SDTEWebApplication.Models;

namespace SDTEWebApplication.Tests.Controllers
{
	[TestClass]
	public class HomeControllerTest
	{

		[TestMethod]
		public void Index_Option1_Count_Palindrome_Empty()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "1";
			inputData.TextareaId = "";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);
			Assert.AreEqual(result.ViewBag.ListOfPalindrome.Length, 0);
		}

		[TestMethod]
		public void Index_Option1_Count_Palindrome_One()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "1";
			inputData.TextareaId = "hello Tom, how are you? Do you know Tom cruise ?";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);
			foreach (String element in result.ViewBag.ListOfPalindrome)
			{
				Assert.AreEqual("?", element);
			}
		}

		[TestMethod]
		public void Index_Option1_Count_Palindrome_two()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "1";
			inputData.TextareaId = "hello aa how are you? Do you know abba cruise";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);
			Assert.AreEqual("aa", result.ViewBag.ListOfPalindrome[0]);
			Assert.AreEqual("abba", result.ViewBag.ListOfPalindrome[1]);
		}


		[TestMethod]
		public void Index_Option1_Count_Palindrome_zero()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "1";
			inputData.TextareaId = "hello Tom, how are you? Do you know Tom cruise";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);
			Assert.AreEqual(0, result.ViewBag.ListOfPalindrome.Length);
		}

		[TestMethod]
		public void Index_Option2_InValid_HTML_Empty()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "2";
			inputData.TextareaId = "";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);

			Assert.AreEqual(result.ViewBag.Balance, 0);

		}

		[TestMethod]
		public void Index_Option2_Valid_HTML()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "2";
			inputData.TextareaId = "<html>hello</html><html>tom</html>";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);

			Assert.AreEqual(result.ViewBag.Balance, -1);

		}

		[TestMethod]
		public void Index_Option2_InValid_HTML()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "2";
			inputData.TextareaId = "<html>aaaaa</html><html>";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);

			//the error shows that at position of 24, not having a closing </html>
			Assert.AreEqual(result.ViewBag.Balance, 24);
		}

		[TestMethod]
		public void Index_Option3_Count_Duplicates()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "3";
			inputData.TextareaId = "Tom is waiting Tom";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);

			Dictionary<string, int> dic = result.ViewBag.ListOfDuplicates;
			Assert.AreEqual(dic.Count, 3);
			Assert.AreEqual(dic["Tom"], 1);
			Assert.AreEqual(dic["is"], 0);
			Assert.AreEqual(dic["waiting"], 0);
		}

		[TestMethod]
		public void Index_Option3_Count_Duplicates_Empty()
		{
			// Arrange
			HomeController controller = new HomeController();
			InputData inputData = new InputData();
			inputData.OptionId = "3";
			inputData.TextareaId = "";

			// Act
			ViewResult result = controller.Process(inputData) as ViewResult;
			Assert.IsNotNull(result);

			Dictionary<string, int> dic = result.ViewBag.ListOfDuplicates;
			Assert.AreEqual(dic.Count, 0);
		}
	}
}
