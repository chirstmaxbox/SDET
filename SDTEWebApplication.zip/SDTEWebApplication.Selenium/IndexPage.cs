﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SDTEWebApplication.Selenium
{
	class IndexPage
	{
		IWebDriver m_driver;
		int waitTime = 1000;

		[SetUp]
		public void startBrowser()
		{
			String path = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
			m_driver = new ChromeDriver(path);
		}

		[Test]
		public void Test_Option1_Palindrome_Two()
		{
			m_driver.Url = "http://localhost:62205/";
			m_driver.Manage().Window.Maximize();
			IWebElement textArea = m_driver.FindElement(By.XPath(".//*[@id='TextareaId']"));
			IWebElement submitButton = m_driver.FindElement(By.XPath(".//*[@value='Submit']"));
			IWebElement option = m_driver.FindElement(By.XPath(".//*[@id='OptionId']"));
			textArea.SendKeys("hello aa how are you? Do you know abba cruise");
			Thread.Sleep(waitTime);
			var selectTest = new SelectElement(option);			
			selectTest.SelectByValue("1");
			Thread.Sleep(waitTime);
			submitButton.Click();
			Thread.Sleep(waitTime);
			IWebElement result = m_driver.FindElement(By.XPath(".//*[@class='myjumbotron']"));
			String s = result.Text;
			Assert.IsTrue(s.Contains("Total of Palindrome: 2"));
			Thread.Sleep(waitTime);
		}

		[Test]
		public void Test_Option2_Valid_HTML()
		{
			m_driver.Url = "http://localhost:62205/";
			m_driver.Manage().Window.Maximize();
			IWebElement textArea = m_driver.FindElement(By.XPath(".//*[@id='TextareaId']"));
			IWebElement submitButton = m_driver.FindElement(By.XPath(".//*[@value='Submit']"));
			IWebElement option = m_driver.FindElement(By.XPath(".//*[@id='OptionId']"));
			textArea.SendKeys("<html>hello</html><html>tom</html>");
			Thread.Sleep(waitTime);
			var selectTest = new SelectElement(option);
			selectTest.SelectByValue("2");
			Thread.Sleep(waitTime);
			submitButton.Click();
			Thread.Sleep(waitTime);
			IWebElement result = m_driver.FindElement(By.XPath(".//*[@class='myjumbotron']"));
			String s = result.Text;
			Assert.IsTrue(s.Contains("It is valid HTML String"));
			Thread.Sleep(waitTime);
		}

		[Test]
		public void Test_Option3_Count_Duplicate()
		{
			m_driver.Url = "http://localhost:62205/";
			m_driver.Manage().Window.Maximize();
			IWebElement textArea = m_driver.FindElement(By.XPath(".//*[@id='TextareaId']"));
			IWebElement submitButton = m_driver.FindElement(By.XPath(".//*[@value='Submit']"));
			IWebElement option = m_driver.FindElement(By.XPath(".//*[@id='OptionId']"));
			textArea.SendKeys("Tom is waiting Tom , Tom");
			Thread.Sleep(waitTime);
			var selectTest = new SelectElement(option);
			selectTest.SelectByValue("3");
			Thread.Sleep(waitTime);
			submitButton.Click();
			Thread.Sleep(waitTime);
			IWebElement result = m_driver.FindElement(By.XPath(".//*[@class='myjumbotron']"));
			String s = result.Text;
			Assert.IsTrue(s.Contains("Tom: 2"));
			Thread.Sleep(waitTime);
		}

		[TearDown]
		public void closeBrowser()
		{
			m_driver.Close();
		}

	}
}
