﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SDTEWebApplication.Controllers
{
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		public ActionResult About()
		{
			ViewBag.Message = "Your application description page.";

			return View();
		}

		public ActionResult Contact()
		{
			ViewBag.Message = "Your contact page.";

			return View();
		}

		private int areHTMLBalanced(String data)
		{
			if (data == null || data == "") return 0;
			/* Declare an empty character stack */
			Stack st = new Stack();
			int failedPosition = -1;
			int position = 0;
			bool flag = true;
			int startHTML = data.IndexOf("<html>", position, StringComparison.OrdinalIgnoreCase);
			int endHTML = data.IndexOf("</html>", position, StringComparison.OrdinalIgnoreCase);
			while(startHTML != -1 || endHTML != -1)
			{
				if (startHTML != -1 && ((startHTML < endHTML) || (endHTML == -1)))
				{
					st.Push("<html>");
					position = startHTML + 6;
				}
				else
				{
					if (st.Count > 0)
					{
						st.Pop();
						position = endHTML + 7;
					}
					else
					{
						flag = false;
						failedPosition = endHTML;
						break;
					}

				}

				startHTML = data.IndexOf("<html>", position, StringComparison.OrdinalIgnoreCase);
				endHTML = data.IndexOf("</html>", position, StringComparison.OrdinalIgnoreCase);
			}

			if(startHTML == endHTML && st.Count != 0 || !flag)
			{
				return position;
			}

			return failedPosition;
		}

		private string Reverse(string s)
		{
			char[] charArray = s.ToCharArray();
			Array.Reverse(charArray);
			return new string(charArray);
		}

		private ArrayList GetPalindromes(String data) 
		{
			ArrayList ret = new ArrayList();
			if (data == null || data == "") return ret;
			String[] datas = data.Split(new[] { "\r\n", " ", "\n" },
												StringSplitOptions.None);
			foreach(String element in datas) {
				if(element.Equals(Reverse(element)))
				{
					ret.Add(element);
				}
			}

			return ret;
		}

		private Dictionary<string, int> GetDuplicates(String data)
		{
			Dictionary<string, int> dic = new Dictionary<string, int>();
			if (data == null || data == "") return dic;
			String[] datas = data.Split(new[] { "\r\n", " ", "\n" },
												StringSplitOptions.None);
			foreach(string element in datas)
			{
				if(dic.ContainsKey(element))
				{
					dic[element] = dic[element] + 1;
				}
				else
				{
					dic.Add(element, 0);
				}
			}
			return dic;
		}

		[HttpPost]
		public ActionResult Process(Models.InputData inputData)
		{
			switch(inputData.OptionId)
			{
				case "1":
					ViewBag.ListOfPalindrome = GetPalindromes(inputData.TextareaId).ToArray();
					break;
				case "2":
					ViewBag.Balance = areHTMLBalanced(inputData.TextareaId);
					break;
				default:
					ViewBag.ListOfDuplicates = GetDuplicates(inputData.TextareaId);
					// it is for option 3
					break;
			}

			ViewBag.Option = inputData.OptionId;
			ViewBag.Result = "abc";
			return View("Index");
		}


	}
}